package com.furniture.furnitureshop.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.furniture.furnitureshop.dao.CartDAO;
import com.furniture.furnitureshop.dao.CategoryDAO;
import com.furniture.furnitureshop.dao.UserDAO;
import com.furniture.furnitureshop.model.Cart;
import com.furniture.furnitureshop.model.Category;
import com.furniture.furnitureshop.model.User;

@Controller
@SessionAttributes("userId")
public class UserController 
{
	 @Autowired
		UserDAO userDAO;
	 
	
	 @RequestMapping("/isValidUser")
		public ModelAndView login(@RequestParam(value = "userId") String userId,
				@RequestParam(value = "password") String password) 
	 {
/*			ModelAndView mv=new ModelAndView("index");
*/		System.out.println("In login controller");	
		 String message;
		 ModelAndView mv;
			if (userDAO.isValidUser(userId, password,true))
			{
				User currUser=userDAO.get(userId);
				if(currUser.isAdmin())
				{
					message="valid Credentials";
					mv=new ModelAndView("adminHome");
					mv.getModelMap().put("userId", userId);
				}
				 else  {
						message="valid Credentials";
					mv=new ModelAndView("userHome");
					mv.getModelMap().put("userId", userId);
					System.out.println(userId);
				}
			}
			else {
				message="Invalid Credentials";

				mv = new ModelAndView("login");
			}
			
			return mv;
		}
	 @RequestMapping("/register")
	 public ModelAndView registerUser(@ModelAttribute User user)
	 {
	userDAO.saveOrUpdate(user);	 
	return new ModelAndView("index");
	 }
	}
