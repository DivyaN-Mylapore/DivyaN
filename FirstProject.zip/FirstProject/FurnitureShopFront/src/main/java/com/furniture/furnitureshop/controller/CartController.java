package com.furniture.furnitureshop.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.furniture.furnitureshop.dao.CartDAO;
import com.furniture.furnitureshop.dao.CategoryDAO;
import com.furniture.furnitureshop.dao.ProductDAO;
import com.furniture.furnitureshop.model.Cart;
import com.furniture.furnitureshop.model.Product;
import com.furniture.furnitureshop.model.User;
import com.google.gson.Gson;

@Controller
@SessionAttributes("userId")
public class CartController {

	@Autowired(required = true)
	private CartDAO cartDAO;

	@Autowired(required = true)
	private ProductDAO productDAO;

	@ModelAttribute("cartdetails")
	public Cart getObject() {

		return new Cart();
	}

	@RequestMapping("/cart")
	public String checkout() {

		return "redirect:/cart?cart";

	}
	@RequestMapping("/sofa")
	public ModelAndView  showgenre(@RequestParam(value = "userId") String userId)
	{
		System.out.println("inside registration controller");
		ModelAndView model = new ModelAndView("sofa");
		System.out.println("userId"+userId);
		model.getModelMap().put("userId", userId);
		model.addObject("productList", this.productDAO.list());
		return model;
	}
	@RequestMapping("/prodinfo")
	public ModelAndView showraven(@RequestParam(value = "bookId") String bookId,@RequestParam(value = "userId") String userId)
	{
		System.out.println("inside productinfo controller"+bookId);
		ModelAndView model = new ModelAndView("prodinfo");
		model.getModelMap().put("userId", userId);
		System.out.println("userId"+userId);
		model.addObject("currProduct", this.productDAO.get(bookId));
		return model;
	}
	@RequestMapping(value="/mycart", method= RequestMethod.GET)
	public String listCart(Model model,@RequestParam(value = "productId") String productId,@RequestParam(value = "currentUserSessionId") String currentUserSessionId){
		System.out.println("productId"+productId);
		System.out.println("currentUserSessionId"+currentUserSessionId);
		Cart currCartProduct = this.cartDAO.getProductsUsingProductIdAndUserId(productId,currentUserSessionId);
		if(null!=currCartProduct){
			int quantity = currCartProduct.getQuantity();
			currCartProduct.setQuantity(quantity+1);
			this.cartDAO.saveOrUpdate(currCartProduct);
		}else{
			Product currProduct = this.productDAO.get(productId);
			Cart cart = new Cart();
			cart.setPrice(currProduct.getPrice());
			cart.setProductId(productId);
			cart.setQuantity(1);
			cart.setSessionUserId(currentUserSessionId);
			cart.setStatus('Y');
			this.cartDAO.saveOrUpdate(cart);
		}
		
		model.addAttribute("cart", new Cart());
		model.addAttribute("user", new User());
		model.addAttribute("product",new Product());
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("cartList", this.cartDAO.list());
		return "mycart";

	}

	@RequestMapping(value ="/cartlist/add/{id}", method=RequestMethod.GET)
	public String addToCart(@PathVariable("id") String id, HttpSession session){
		Product product= productDAO.get(id);
		System.out.println("inside");
		Cart cart=new Cart();
		cart.setPrice(product.getPrice());
		cart.setProductId(product.getId());
		cart.setQuantity(1);
		cart.setStatus('N');
		cartDAO.saveOrUpdate(cart);
		//return "redirect:views/home.jsp";
		return "redirect:/mycart";
	}

	@RequestMapping("cart/remove/{id}")
	public String removeCart(@PathVariable("id") String id,ModelMap model) throws Exception{

		try {
			cartDAO.delete(id);
			model.addAttribute("message","Successfully removed");
		} catch (Exception e) {
			model.addAttribute("message",e.getMessage());
			e.printStackTrace();
		}
		//redirectAttrs.addFlashAttribute(arg0, arg1)
		return "redirect:/mycart";
	}

	@RequestMapping("cart/edit/{id}")
	public String editCart(@PathVariable("id") String id, Model model){
		System.out.println("editCart");
		model.addAttribute("cart", this.cartDAO.get(Integer.parseInt(id)));
		model.addAttribute("listCarts", this.cartDAO.list());
		return "cart";
	}

	
}
