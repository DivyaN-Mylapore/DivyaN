package com.furniture.furnitureshop.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.furniture.furnitureshop.dao.CartDAO;
import com.furniture.furnitureshop.model.Cart;

public class CartTest
{
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.furniture.furnitureshop");
		context.refresh();
		
	Cart ct =(Cart)	  context.getBean("cart");
	
	CartDAO cartDAO = (CartDAO)  context.getBean("cartDAO");
	


/*	ct.setcid(1011);
*/	ct.setProductId("101");
ct.setSessionUserId("10");
	ct.setQuantity(1);
	ct.setPrice("15000");
	ct.setStatus('N');
	/*ct.setId("Divya");*/
	cartDAO.saveOrUpdate(ct);
	
	
	
		
		
	}

}
