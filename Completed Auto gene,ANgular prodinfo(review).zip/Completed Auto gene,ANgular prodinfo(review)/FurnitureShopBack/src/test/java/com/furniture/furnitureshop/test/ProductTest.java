package com.furniture.furnitureshop.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.furniture.furnitureshop.dao.CategoryDAO;
import com.furniture.furnitureshop.dao.ProductDAO;
import com.furniture.furnitureshop.model.Category;
import com.furniture.furnitureshop.model.Product;

public class ProductTest {
	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.furniture.furnitureshop");
		context.refresh();

		Product c = (Product) context.getBean("product");

		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");

/*		c.setId("D4389");
*/		c.setName("Dining Table");
		c.setDescription("Wooden");
		c.setPrice(18000);

		productDAO.saveOrUpdate(c);

	}

}
