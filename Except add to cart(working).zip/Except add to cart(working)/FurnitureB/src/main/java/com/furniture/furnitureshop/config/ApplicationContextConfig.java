package com.furniture.furnitureshop.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.furniture.furnitureshop.dao.CartDAO;
import com.furniture.furnitureshop.dao.CartDAOImpl;
import com.furniture.furnitureshop.dao.CategoryDAO;
import com.furniture.furnitureshop.dao.CategoryDAOImpl;
import com.furniture.furnitureshop.dao.SupplierDAOImpl;
import com.furniture.furnitureshop.dao.UserDAO;
import com.furniture.furnitureshop.dao.UserDAOImpl;
import com.furniture.furnitureshop.model.Cart;
import com.furniture.furnitureshop.model.Category;
import com.furniture.furnitureshop.model.Product;
import com.furniture.furnitureshop.model.Supplier;
import com.furniture.furnitureshop.model.User;
import com.furniture.furnitureshop.model.UserDetails;
@Configuration
@ComponentScan("com.furniture.furnitureshop")
@EnableTransactionManagement

public class ApplicationContextConfig
{
	@Bean(name = "dataSource")
    public DataSource getDataSource() {
    	BasicDataSource dataSource = new BasicDataSource();
    	dataSource.setDriverClassName("org.h2.Driver");
    	dataSource.setUrl("jdbc:h2:tcp://localhost/~/furniturelatt");
    	dataSource.setUsername("sa");
    	dataSource.setPassword("");
    	
    	return dataSource;
    }
    
    
    private Properties getHibernateProperties() {
    	Properties properties = new Properties();
    	properties.put("hibernate.show_sql", "true");
    	properties.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
    	properties.put("hibernate.hbm2ddl.auto", "update");
    	return properties;
    }
    
    @Autowired
    @Bean(name = "sessionFactory")
    public SessionFactory getSessionFactory(DataSource dataSource) {
    	LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
    	sessionBuilder.addProperties(getHibernateProperties());
    	sessionBuilder.addAnnotatedClasses(User.class);
    	sessionBuilder.addAnnotatedClasses(Cart.class);
  	sessionBuilder.addAnnotatedClasses(UserDetails.class);
    	sessionBuilder.addAnnotatedClasses(Category.class);
    	sessionBuilder.addAnnotatedClasses(Supplier.class);
    	sessionBuilder.addAnnotatedClasses(Product.class);

    	return sessionBuilder.buildSessionFactory();
    }
    
	@Autowired
	@Bean(name = "transactionManager")
	public HibernateTransactionManager getTransactionManager(
			SessionFactory sessionFactory) {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager(
				sessionFactory);

		return transactionManager;
	}
    @Autowired
    @Bean(name = "categoryDAO")
    public CategoryDAO getCategoryDAO(SessionFactory sessionFactory) {
    	return new CategoryDAOImpl(sessionFactory);
    }
    @Autowired
    @Bean(name = "supplierDAO")
    public SupplierDAOImpl getSupplierDAO(SessionFactory sessionFactory) {
    	return new SupplierDAOImpl(sessionFactory);
    }
    @Autowired
    @Bean(name = "userDAO")
    public UserDAO getUserDAO(SessionFactory sessionFactory) {
    	return new UserDAOImpl(sessionFactory);
    }
    @Autowired
    @Bean(name = "cartDAO")
    public CartDAO getCartDAO(SessionFactory sessionFactory) {
    	return new CartDAOImpl(sessionFactory);
    }


}
