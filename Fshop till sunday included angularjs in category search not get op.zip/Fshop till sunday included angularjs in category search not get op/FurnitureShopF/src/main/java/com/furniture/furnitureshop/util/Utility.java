
package com.furniture.furnitureshop.util;

public class Utility {
	
	public String replace(String st,String ch1,String ch2){
		
		return st.replace(ch1, ch2);
	}
	
	public static void main(String[] args) {
		
		System.out.println("REPLACE");
		Utility u= new Utility();
		String n;
		n=u.replace(",pro",",","");
		System.out.println(n);
		
	}

}
