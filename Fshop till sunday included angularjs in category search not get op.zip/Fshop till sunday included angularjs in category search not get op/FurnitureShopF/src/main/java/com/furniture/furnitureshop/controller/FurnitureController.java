package com.furniture.furnitureshop.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class FurnitureController 
{
	@RequestMapping("/")
	public String helloWorld()
	{
		return "index";
	}
     @RequestMapping("/index")
    public String gotoHome()
    {
    	return "index";
    }
     @RequestMapping("/login")
     public String gotoLogin()
     {
     	return "login";
     }
     
     @RequestMapping("/signup")
     public String gotoSignup()
     {
     	return "signup";
     }
     @RequestMapping("/aboutus")
     public String gotoAbout()
     {
     	return "aboutus";
     }
     
     @RequestMapping("/contactus")
     public String gotoContact()
     {
     	return "contactus";
     }
     @RequestMapping("/sofa")
     public String gotoSofa()
     {
     	return "sofa";
     }
     @RequestMapping("/cot")
     public String gotoCot()
     {
     	return "cot";
     }
    
}
