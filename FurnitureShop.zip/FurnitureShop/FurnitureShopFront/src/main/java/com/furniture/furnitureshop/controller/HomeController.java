package com.furniture.furnitureshop.controller;

import javax.servlet.http.HttpSession;

/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/*import com.furniture.furnitureshop.dao.CartDAO;
*/import com.furniture.furnitureshop.dao.CategoryDAO;
import com.furniture.furnitureshop.dao.UserDAO;
/*import com.furniture.furnitureshop.model.Cart;
*/import com.furniture.furnitureshop.model.Category;
import com.furniture.furnitureshop.model.User;

@Controller
public class HomeController {
	
/*	Logger log = LoggerFactory.getLogger(HomeController.class);
*/	
	@Autowired
	User user;

	@Autowired
	private CategoryDAO categoryDAO;
	
	@Autowired
	private UserDAO userDAO;

	@Autowired
	private Category category;
	/*@RequestMapping("/")
	public ModelAndView onLoad(HttpSession session) {
		log.debug("Starting of the method onLoad");
		ModelAndView mv = new ModelAndView("/home");
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
		log.debug("Ending of the method onLoad");
		return mv;
	}*/
@RequestMapping(value = "/signup", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute User user) {
	ModelAndView mv  = new ModelAndView("index");
	if(userDAO.get(user.getName())==null)
	{
		userDAO.saveOrUpdate(user);
	}
	else
	{
		mv.addObject("msg","User exist with this id");
	}
		
		mv.addObject("successMessage", "You are successfully register");
		
		return mv;
	}

	@RequestMapping("/signup")
	public ModelAndView registerHere() {
		ModelAndView mv = new ModelAndView("signup");
		mv.addObject("user",user);
		mv.addObject("isUserClickedRegisterHere", "true");
		return mv;
	}

	@RequestMapping("/login")
	public ModelAndView loginHere() {
		ModelAndView mv = new ModelAndView("login");
		mv.addObject("user", new User());
		mv.addObject("isUserClickedLoginHere", "true");
		return mv;
	}



}