package com.furniture.furnitureshop.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.furniture.furnitureshop.dao.CartDAO;
import com.furniture.furnitureshop.dao.CategoryDAO;
import com.furniture.furnitureshop.dao.ProductDAO;
import com.furniture.furnitureshop.model.Cart;
import com.furniture.furnitureshop.model.Product;
import com.furniture.furnitureshop.model.User;


@Controller
public class CartController {
	
	
	@Autowired(required=true)
	private CartDAO cartDAO;
	
	@Autowired(required=true)
	private ProductDAO productDAO;
	
	
	@ModelAttribute("cartdetails")
	public Cart getObject()
	{
		
		return new Cart() ;
	}
	
	@RequestMapping("/cart")
	public String checkout(){
		
		return "redirect:/cart?cart";
		
	}
	/*@RequestMapping(value = "/myCart", method = RequestMethod.GET)
	public String Cart(Model model) {
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", categoryDAO.list());
		model.addAttribute("cart", new Cart());
	String loggedInUserid=(String)session.getAttribute("loggedInUserID");	
	System.out.println("User"+loggedInUserid);
	System.out.println("in Cartcontroller");
		model.addAttribute("cartList", this.cartDAO.list(loggedInUserid));
		model.addAttribute("totalAmount", cartDAO.getTotalAmount(loggedInUserid)); // Just to test, passwrdo user
		model.addAttribute("displayCart", "true");
		return "cart";
	}*/
	@RequestMapping(value = "/mycart", method = RequestMethod.GET)
	public String listCart(Model model) {
		model.addAttribute("cart", new Cart());
		model.addAttribute("user", new User());
		model.addAttribute("product", new Product());
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("cartList", this.cartDAO.list());
	
		return "mycart";
	}
	
/*	@RequestMapping(value = "/carts", method = RequestMethod.GET)
	public String listCarts(Model model) {
		model.addAttribute("cart", new Cart());
		model.addAttribute("cartList", this.cartDAO.list());
		return "cart";
	}*/
	

	//For add and update cart both
	@RequestMapping(value= "/cart/add/{id}", method = RequestMethod.GET)
	public String addToCart(@PathVariable("id") String id,HttpSession session){
		
	
	 Product product =	 productDAO.get(id);
	 System.out.println( "get Id");
	 Cart cart = new Cart();
	 cart.setPrice(product.getPrice());
	 cart.setProductName(product.getName());
	 cart.setQuantity(1);
	 /*String loggedInUserid=(String)session.getAttribute("loggedInUserid");
	 cart.setId("loggedInUserid"); */ //  id should keep session and use the same id
	 cart.setStatus('N');  // 
		cartDAO.saveOrUpdate(cart);
		//return "redirect:/views/home.jsp";
		return "redirect:/cart";
		
	}
	
	@RequestMapping("cart/remove/{cid}")
    public String removeCart(@PathVariable("cid") String cid,ModelMap model) throws Exception{
		
       try {
		cartDAO.delete(cid);
		model.addAttribute("message","Successfully removed");
	} catch (Exception e) {
		model.addAttribute("message",e.getMessage());
		e.printStackTrace();
	}
       //redirectAttrs.addFlashAttribute(arg0, arg1)
        return "redirect:/cart";
    }
 
    @RequestMapping("cart/edit/{id}")
    public String editCart(@PathVariable("id") String id, Model model){
    	System.out.println("editCart");
        model.addAttribute("cart", this.cartDAO.get(id));
        model.addAttribute("listCarts", this.cartDAO.list());
        return "cart";
    }
	}
