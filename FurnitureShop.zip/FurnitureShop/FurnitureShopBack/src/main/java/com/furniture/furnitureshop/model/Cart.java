package com.furniture.furnitureshop.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.stereotype.Component;

@Entity
@Table(name="CART")
@Component
public class Cart implements Serializable{
	
	private static final long serialVersionUID = 18L;
	
	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	private String cid;
	
	@Transient
	private Long total;
	private String id;
	private String productName;
	private double price;
	private int quantity;
	private char status;
	
	public Long getTotal() {
		return total;
	}
	
	public void setCartid(String cid) {
		this.cid = cid;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public void setTotal(Long total) {
		this.total = total;
	}
	public String getCId() {
		return cid;
	}
	public void setCId(String cid) {
		this.cid = cid;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String Id) {
		this.id = Id;
	}
	
	public double getPrice() {
		return price;
	}
	public void setPrice(double d) {
		this.price = d;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public char getStatus() {
		return status;
	}
	public void setStatus(char status) {
		this.status = status;
	}
	private String name;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getMobile() {
		return mobile;
	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	private String address;
	private int mobile;	

}
