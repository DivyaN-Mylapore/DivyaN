package com.furniture.furnitureshop.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.furniture.furnitureshop.dao.CategoryDAO;
import com.furniture.furnitureshop.model.Category;

import antlr.collections.List;

public class CategoryTest
{
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.furniture.furnitureshop");
		context.refresh();
		
	Category c =(Category)	  context.getBean("category");
	
	CategoryDAO categoryDAO = (CategoryDAO)  context.getBean("categoryDAO");
	


	c.setId("S1011");
	c.setName("Sofa");
	c.setDescription("A  sofa is a piece of home furniture for seating two or more people in the form of a bench.");
	categoryDAO.saveOrUpdate(c);

	
	
		
		
	}

}
