package com.furni.fshop.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.furni.fshop.dao.CategoryDAO;
import com.furni.fshop.dao.ProductDAO;
import com.furni.fshop.model.Category;
import com.furni.fshop.model.Product;

public class ProductTest {
	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.furni.fshop");
		context.refresh();

		Product c = (Product) context.getBean("product");

		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");

		c.setId("D438");
		c.setName("Dining Table");
		c.setDescription("Wooden");
		c.setPrice((double) 18000);

		productDAO.saveOrUpdate(c);

	}

}
