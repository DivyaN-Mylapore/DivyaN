package com.furniture.furnitureshop.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.furniture.furnitureshop.model.Category;
import com.furniture.furnitureshop.model.Supplier;

@Repository("supplierDAO")

public class SupplierDAOImpl implements SupplierDAO
{
	@Autowired
	private SessionFactory sessionFactory;


	public SupplierDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<Supplier> list() {
		@SuppressWarnings("unchecked")
		List<Supplier> list = (List<Supplier>) sessionFactory.getCurrentSession()
				.createCriteria(Supplier.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}

	/*@Transactional
	public void save(Supplier supplier) {
		sessionFactory.getCurrentSession().save(supplier);
	}*/
	/*@Transactional
	public void saveOrUpdate(Supplier supplier) {
		
		System.out.println("am in save or update");
		sessionFactory.getCurrentSession().saveOrUpdate(supplier);
	}
*/

	@Transactional
	public void save(Supplier supplier) {
	//String str = "CAT_";
	//System.out.println("save method");
	//int a = counter.getAndIncrement();
	//String con = Integer.toString(a);
	//category.setId(str + con);
	System.out.println("*********Supplier DAO********");
	Session s=sessionFactory.getCurrentSession();
	s.save(supplier);
	s.flush();
	}

	@Transactional
	public void delete(String id) {
		Supplier SupplierToDelete = new Supplier();
		SupplierToDelete.setId(id);
		sessionFactory.getCurrentSession().delete(SupplierToDelete);
	}

	@Transactional
	public Supplier get(String id) {
		String hql = "from Supplier where id=" + "'" + id + "'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Supplier> list = (List<Supplier>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;
	}

	@Transactional
	public Supplier getByName(String name) {
		String hql = "from Supplier where name=" + "'" + name + "'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Supplier> listSupplier = (List<Supplier>) query.list();
		
		if (listSupplier != null && !listSupplier.isEmpty()) {
			return listSupplier.get(0);
		}
		
		return null;
	}

}
