package com.furniture.furnitureshop.test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.furniture.furnitureshop.dao.UserDAO;
import com.furniture.furnitureshop.model.User;
/*import com.furniture.furnitureshop.model.UserDetails;
*/

public class Test {
	
	static AnnotationConfigApplicationContext context;
	
	public Test()
	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.furniture.furnitureshop");
		context.refresh();
	}
	
	public static void createUser(User user)
	{
		
		UserDAO  userDAO =  (UserDAO) context.getBean("userDAO");
		userDAO.saveOrUpdate(user);
		
		
	}

	public static void main(String[] args) {
		
		Test t = new Test();
		
		User user =(User)  context.getBean("user");
		user.setId("Divya");
		user.setPassword("divi");
		user.setName("Divya Narayanasamy");
		user.setEmail("divya@gmail.com");
		user.setAddress("Chennai");
	user.setAdmin(false);	
	user.setMobile("8043423460");
/*		userDetails.setAdmin();
*/		
	user.setId("Admin");
	user.setPassword("admin");
	user.setName("Adminisatrator");
	user.setEmail("admin@gmail.com");
	user.setAddress("Mumbai");
user.setAdmin(true);	
user.setMobile("8043456631");
		t.createUser(user);
		
		
	}

	

}
