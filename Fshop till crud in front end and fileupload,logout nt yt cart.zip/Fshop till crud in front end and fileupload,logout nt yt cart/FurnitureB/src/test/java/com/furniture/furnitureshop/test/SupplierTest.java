package com.furniture.furnitureshop.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.furniture.furnitureshop.dao.SupplierDAO;
import com.furniture.furnitureshop.model.Supplier;

public class SupplierTest 
{
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.furniture.furnitureshop");
		context.refresh();
		
	Supplier s =(Supplier)	  context.getBean("supplier");
	
	SupplierDAO supplierDAO = (SupplierDAO)  context.getBean("supplierDAO");
	
/*	s.setId("S1011");
*/	s.setName("Johnsons");
	s.setAddress("Hyderabad");
	
	
	supplierDAO.save(s);

	
	
		
		
	}

}
