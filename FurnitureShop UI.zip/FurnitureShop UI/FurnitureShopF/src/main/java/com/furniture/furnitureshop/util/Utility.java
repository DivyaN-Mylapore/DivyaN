
package com.furniture.furnitureshop.util;

public class Utility {
	
	public String replace(String str,String str1,String str2){
		
		String newString= replace(str,str1,str2);
		return newString;
	}
	
	public static void main(String[] args) {
		
		System.out.println("REPLACE");
		Utility u= new Utility();
		String n;
		n=u.replace(",pro",",","");
		System.out.println(n);
		
	}

}
