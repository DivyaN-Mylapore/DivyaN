package com.furniture.furnitureshop.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class FurnitureController 
{
	@RequestMapping("/")
	public String helloWorld()
	{
		return "index";
	}
     @RequestMapping("/index")
    public String gotoHome()
    {
    	return "index";
    }
    /* @RequestMapping("/login")
     public String gotoLogin()
     {
     	return "login";
     }
     
     @RequestMapping("/signup")
     public String gotoSignup()
     {
     	return "signup";
     }*/
    
     @RequestMapping("/aboutus")
     public String gotoAbout()
     {
     	return "aboutus";
     }
     
     @RequestMapping("/contactus")
     public String gotoContact()
     {
     	return "contactus";
     }
     @RequestMapping("/sofa")
     public String gotoSofa()
     {
     	return "sofa";
     }
     @RequestMapping("/cot")
     public String gotoCot()
     {
     	return "cot";
     }
     @RequestMapping("/tvcabinet")
     public String gotoTV()
     {
     	return "tvcabinet";
     }
     @RequestMapping("/conference table")
     public String gotoConference()
     {
     	return "conference table";
     }
     @RequestMapping("/diningchair")
     public String gotoDiningChair()
     {
     	return "diningchair";
     }
     @RequestMapping("/officechair")
     public String gotoOfficeChair()
     {
     	return "officechair";
     }
     @RequestMapping("/diningtable")
     public String gotoDiningTable()
     {
     	return "diningtable";
     }
     
     @RequestMapping("/upload")
     public String gotoUpload()
     {
     	return "upload";
     }
     @RequestMapping("/prodinfo1")
     public String gotoProduct1()
     {
     	return "prodinfo1";
     }
     @RequestMapping("/prodinfo2")
     public String gotoProduct2()
     {
     	return "prodinfo2";
     }
     @RequestMapping("/prodinfo3")
     public String gotoProduct3()
     {
     	return "prodinfo3";
     }
     @RequestMapping("/prodinfo4")
     public String gotoProduct4()
     {
     	return "prodinfo4";
     }
     /*@RequestMapping("/prodinfo")
     public String gotoInfo()
     {
     	return "prodinfo";
     }*/
   /*  @RequestMapping("/mycart")
     public String gotoCart()
     {
    	 return "mycart";
     }*/
     
}
