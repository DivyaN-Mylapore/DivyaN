package com.furniture.furnitureshop.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.furniture.furnitureshop.dao.CartDAO;
import com.furniture.furnitureshop.dao.CategoryDAO;
import com.furniture.furnitureshop.dao.UserDAO;
import com.furniture.furnitureshop.model.Cart;
import com.furniture.furnitureshop.model.Category;
import com.furniture.furnitureshop.model.User;

@Controller
public class UserController 
{
	 @Autowired
		UserDAO userDAO;
	 @Autowired
	 User user;
	 @Autowired
	 CartDAO cartDAO;
	 @Autowired
	 Cart cart;
	 @Autowired
	 Category category;
	 @Autowired
	 CategoryDAO categoryDAO;

	 @RequestMapping("/isValidUser")
		public ModelAndView login(@RequestParam(value = "name") String name,
				@RequestParam(value = "password") String password, HttpSession session) 
	 {
/*			ModelAndView mv=new ModelAndView("index");
*/			
		 ModelAndView mv;
			boolean isValidUser = userDAO.isValidUser(name, password);
			if (isValidUser == true)
			{
				user = userDAO.get(name);
				session.setAttribute("loggedInUser", user.getName());
				session.setAttribute("loggedInUserId", user.getId());
				session.setAttribute("user", user);
				if (user.isAdmin() == true) {
					 mv=new ModelAndView("adminHome");
					mv.addObject("isAdmin", "true");
				} else  {
					 mv=new ModelAndView("index");
					mv.addObject("isAdmin", "false");
					cart = cartDAO.get(name);
					mv.addObject("cart", cart);
					List<Cart> cartList = cartDAO.list();
					mv.addObject("cartList", cartList);
					mv.addObject("cartSize", cartList.size());
					
				}
			}
			else {
				mv=new ModelAndView("login");
				mv.addObject("invalidCredentials", "true");
				mv.addObject("errorMessage", "Invalid Credentials");
				

			}
			return mv;
		}
	 
	 @RequestMapping("/logout")
		public ModelAndView logout(HttpServletRequest request, HttpSession session) {
			ModelAndView mv = new ModelAndView("index");
			session.invalidate();
			session = request.getSession(true);
			session.setAttribute("category", category);
			session.setAttribute("categoryList", categoryDAO.list());
		
			mv.addObject("logoutMessage", "You successfully logged out");
			mv.addObject("loggedOut", "true");
		
			return mv;
		 }

	 
	 
	 
	 
	 
	/*	@RequestMapping("/isValidUser")
		public ModelAndView showMessage(@RequestParam(value = "name") String name,
				@RequestParam(value = "password") String password ) {
			System.out.println("in controller");

			String message;
			ModelAndView mv ;
			if (userDAO.isValidUser(name, password,true)) 
			{
				message = "Valid credentials";
				 mv = new ModelAndView("adminHome");
				 
			} 
			else if (userDAO.isValidUser(name, password,false)) 
			{
				message = "Valid credentials";
				 mv = new ModelAndView("home");
			
			}
			else {
				message = "Invalid credentials";
				 mv = new ModelAndView("login");
				 
			}
			ModelAndView mv = new ModelAndView("success");
			mv.addObject("message", message);
			mv.addObject("name", name);			// mv.addObject("password", password);
		return mv;
 	}*/

	/*	@RequestMapping(value = "/register", method = RequestMethod.POST)
	    public String doLogin(@Valid @ModelAttribute("user") User user,
	            BindingResult result, Map<String, Object> model) {
	 System.out.println(user);
	        if (result.hasErrors()) {
	            return "signup";
	        }
	        userDAO.saveOrUpdate(user);
	        return "home";
		}
*/
	/*@RequestMapping(value = "/signup", method = RequestMethod.POST)
		public String doLogin(@Valid User user, BindingResult result) {

			if (result.hasErrors()) {
				return "signup";
			} 
			else {
				userDAO.saveOrUpdate(user);
				return "index";
			}
	}*/
}
