
package com.furniture.furnitureshop.util;

public class Utility {
	
	public  static String removeComma(String name)
	{
		return name.replace(",", "");
	}
	
	
}
